package main;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import model.Ajuste;
import model.Boleto;

public class Run {
	public static void main(String[] args) {
		List<Ajuste> ajustes = new ArrayList();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		Boleto b1 = new Boleto();
		b1.setBoleto_id(1);
		b1.setCreated_time(LocalDate.parse("18/01/2019", formatter));
		b1.setAmount(100.00);
		b1.setDue_date(LocalDate.parse("20/03/2019", formatter));
		
		Boleto b2 = new Boleto();
		b2.setBoleto_id(2);
		b2.setCreated_time(LocalDate.parse("18/02/2019", formatter));
		b2.setAmount(80.00);
		b2.setDue_date(LocalDate.parse("20/03/2019", formatter));
		
		Boleto b3 = new Boleto();
		b3.setBoleto_id(3);
		b3.setCreated_time(LocalDate.parse("18/03/2019", formatter));
		b3.setAmount(10.00);
		b3.setDue_date(LocalDate.parse("20/03/2019", formatter));
		
		Boleto b4 = new Boleto();
		b4.setBoleto_id(4);
		b4.setCreated_time(LocalDate.parse("10/01/2019", formatter));
		b4.setAmount(20.00);
		b4.setDue_date(LocalDate.parse("15/01/2019", formatter));
		
		Boleto b5 = new Boleto();
		b5.setBoleto_id(5);
		b5.setCreated_time(LocalDate.parse("12/02/2019", formatter));
		b5.setAmount(50.00);
		b5.setDue_date(LocalDate.parse("13/02/2019", formatter));
		
		Boleto b6 = new Boleto();
		b6.setBoleto_id(6);
		b6.setCreated_time(LocalDate.parse("20/03/2019", formatter));
		b6.setAmount(50.00);
		b6.setDue_date(LocalDate.parse("25/03/2019", formatter));
		
		Ajuste a1 = new Ajuste();
		a1.setAjuste_id(1);
		a1.setBoleto(b1);
		a1.setStatus("ativo");
		a1.setCreated_time(b1.getCreated_time());
		
		Ajuste a2 = new Ajuste();
		a2.setAjuste_id(2);
		a2.setBoleto(b2);
		a2.setStatus("ativo");
		a2.setCreated_time(b2.getCreated_time());
		
		Ajuste a3 = new Ajuste();
		a3.setAjuste_id(3);
		a3.setBoleto(b3);
		a3.setStatus("ativo");
		a3.setCreated_time(b3.getCreated_time());
		
		Ajuste a4 = new Ajuste();
		a4.setAjuste_id(4);
		a4.setBoleto(b4);
		a4.setStatus("ativo");
		a4.setCreated_time(b4.getCreated_time());
		
		Ajuste a5 = new Ajuste();
		a5.setAjuste_id(5);
		a5.setBoleto(b5);
		a5.setStatus("ativo");
		a5.setCreated_time(b5.getCreated_time());
		
		Ajuste a6 = new Ajuste();
		a6.setAjuste_id(6);
		a6.setBoleto(b6);
		a6.setStatus("ativo");
		a6.setCreated_time(b6.getCreated_time());
		
		Ajuste a7 = new Ajuste();
		a7.setAjuste_id(7);
		a7.setBoleto(b5);
		a5.setStatus("cancelado");
		a7.setCreated_time(LocalDate.parse("14/02/2019", formatter));
		
		Ajuste a8 = new Ajuste();
		a8.setAjuste_id(8);
		a8.setBoleto(b6);
		a6.setStatus("cancelado");
		a8.setCreated_time(LocalDate.parse("27/03/2019", formatter));
		

		ajustes.add(a1);
		ajustes.add(a2);
		ajustes.add(a3);
		ajustes.add(a4);
		ajustes.add(a5);
		ajustes.add(a6);
		ajustes.add(a7);
		ajustes.add(a8);
		
		  
		
		System.out.println("\n\n*******************BOLETOS ATIVOS***************************\n");
		
		//Trazer todos boletos ativos do sistema
		ajustes.stream().filter(ativo ->(ativo.getStatus().equals("ativo"))).forEach(ativo ->{
			System.out.println(ativo.getBoleto());
		});
		
		System.out.println("\n\n**********BOLETOS CANCELADOS DE DATA ESPECIFICA*************\n");
		
		//Trazer todos boletos cancelados de uma data espec�fica
		ajustes.stream().filter(cancelado ->(cancelado.getStatus().equals("cancelado"))& cancelado.getCreated_time().equals(LocalDate.parse("27/03/2019",formatter))).forEach(cancelado ->{
			System.out.println(cancelado.getBoleto());
		});
				
		System.out.println("\n\n**************TODOS AJUSTES DE UM BOLETO*********************\n");
		
		//Trazer todos os ajustes de um boleto :
				System.out.println(ajustes);
		
	}
	
}

package model;

import java.time.LocalDate;

public class Ajuste {
	private long ajuste_id;
	private Boleto boleto;
	private String status = "cancelado";
	private LocalDate created_time;
	public long getAjuste_id() {
		return ajuste_id;
	}
	public void setAjuste_id(long ajuste_id) {
		this.ajuste_id = ajuste_id;
	}
	public Boleto getBoleto() {
		return boleto;
	}
	public void setBoleto(Boleto boleto) {
		this.boleto = boleto;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDate getCreated_time() {
		return created_time;
	}
	public void setCreated_time(LocalDate created_time) {
		this.created_time = created_time;
	}
	@Override
	public String toString() {
		return "Ajuste: ajuste_id=" + ajuste_id + ", boleto=" + boleto + ", status=" + status + ", created_time="
				+ created_time + "\n";
	}
	
	
}

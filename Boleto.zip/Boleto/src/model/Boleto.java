package model;

import java.time.LocalDate;

public class Boleto {
	private long boleto_id;
	private LocalDate created_time;
	private double amount;
	private LocalDate due_date;
	
	
	public long getBoleto_id() {
		return boleto_id;
	}
	public void setBoleto_id(long boleto_id) {
		this.boleto_id = boleto_id;
	}
	public LocalDate getCreated_time() {
		return created_time;
	}
	public void setCreated_time(LocalDate created_time) {
		this.created_time = created_time;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public LocalDate getDue_date() {
		return due_date;
	}
	public void setDue_date(LocalDate due_date) {
		this.due_date = due_date;
	}
	@Override
	public String toString() {
		return "Boleto [boleto_id=" + boleto_id + ", created_time=" + created_time + ", amount=" + amount
				+ ", due_date=" + due_date + "]";
	}
	
	
}
